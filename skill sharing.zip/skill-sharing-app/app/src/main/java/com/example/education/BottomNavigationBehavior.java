package com.example.education;

public class BottomNavigationBehavior {
}
