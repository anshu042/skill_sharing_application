package Model;

public class Profile_Course_Model {

}
